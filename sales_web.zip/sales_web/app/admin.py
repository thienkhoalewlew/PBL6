from django.contrib import admin
from .models import CustomerInfo, Product

admin.site.register(CustomerInfo)
admin.site.register(Product)